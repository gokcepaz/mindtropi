<!-- eslint-disable max-len -->
<template>
  <section>
    <h1 class="page-title">UI - <span class="fw-semi-bold">Icons</span></h1>
    <b-tabs>
      <b-tab title="Glyphicons" active>
        <h4>Built-in <span class="fw-semi-bold">Glyphicons</span></h4>
        <b-row class="icon-list">
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-asterisk" />asterisk</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-plus" />plus</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-euro" />euro</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-minus" />minus</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-cloud" />cloud</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-envelope" />envelope</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span
            class="glyphicon glyphicon-pencil"
          />pencil</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-glass" />glass</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-music" />music</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span
            class="glyphicon glyphicon-search"
          />search</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-heart" />heart</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-star" />star</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-star-empty" />star-empty</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-user" />user</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-film" />film</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-th-large" />th-large</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-th" />th</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span
            class="glyphicon glyphicon-th-list"
          />th-list</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-ok" />ok</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span
            class="glyphicon glyphicon-remove"
          />remove</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span
            class="glyphicon glyphicon-zoom-in"
          />zoom-in</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-zoom-out" />zoom-out</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-off" />off</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span
            class="glyphicon glyphicon-signal"
          />signal</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-cog" />cog</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-trash" />trash</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-home" />home</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-file" />file</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-time" />time</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-road" />road</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-download-alt" />download-alt</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-download" />download</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span
            class="glyphicon glyphicon-upload"
          />upload</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-inbox" />inbox</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-play-circle" />play-circle</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span
            class="glyphicon glyphicon-repeat"
          />repeat</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span
            class="glyphicon glyphicon-refresh"
          />refresh</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-list-alt" />list-alt</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span
            class="glyphicon glyphicon-glyph-lock"
          />lock</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-flag" />flag</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-headphones" />headphones</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-volume-off" />volume-off</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-volume-down" />volume-down</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-volume-up" />volume-up</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span
            class="glyphicon glyphicon-qrcode"
          />qrcode</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span
            class="glyphicon glyphicon-barcode"
          />barcode</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-tag" />tag</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-tags" />tags</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-book" />book</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-glyph-bookmark" />bookmark</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-print" />print</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-glyph-camera" />camera</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-font" />font</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-bold" />bold</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span
            class="glyphicon glyphicon-italic"
          />italic</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-text-height" />text-height</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-text-width" />text-width</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-align-left" />align-left</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-align-center" />align-center</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-align-right" />align-right</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-align-justify" />align-justify</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-list" />list</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-indent-left" />indent-left</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-indent-right" />indent-right</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-facetime-video" />facetime-video</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span
            class="glyphicon glyphicon-picture"
          />picture</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-map-marker" />map-marker</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span
            class="glyphicon glyphicon-adjust"
          />adjust</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-tint" />tint</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-edit" />edit</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-share" />share</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-check" />check</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-move" />move</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-step-backward" />step-backward</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-fast-backward" />fast-backward</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-backward" />backward</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-play" />play</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-pause" />pause</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-stop" />stop</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span
            class="glyphicon glyphicon-forward"
          />forward</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-fast-forward" />fast-forward</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-step-forward" />step-forward</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-eject" />eject</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-chevron-left" />chevron-left</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-chevron-right" />chevron-right</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-plus-sign" />plus-sign</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-minus-sign" />minus-sign</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-remove-sign" />remove-sign</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span
            class="glyphicon glyphicon-ok-sign"
          />ok-sign</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-question-sign" />question-sign</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-info-sign" />info-sign</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-screenshot" />screenshot</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-remove-circle" />remove-circle</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-ok-circle" />ok-circle</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-ban-circle" />ban-circle</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-arb-row-left" />arb-row-left</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-arb-row-right" />arb-row-right</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-arb-row-up" />arb-row-up</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-arb-row-down" />arb-row-down</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-share-alt" />share-alt</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-resize-full" />resize-full</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-resize-small" />resize-small</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-exclamation-sign" />exclamation-sign</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-gift" />gift</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-leaf" />leaf</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span
            class="glyphicon glyphicon-glyph-fire"
          />fire</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-eye-open" />eye-open</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-eye-close" />eye-close</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-warning-sign" />warning-sign</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-plane" />plane</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-glyph-calendar" />calendar</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span
            class="glyphicon glyphicon-random"
          />random</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span
            class="glyphicon glyphicon-comment"
          />comment</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span
            class="glyphicon glyphicon-magnet"
          />magnet</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-chevron-up" />chevron-up</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-chevron-down" />chevron-down</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span
            class="glyphicon glyphicon-retweet"
          />retweet</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-shopping-cart" />shopping-cart</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-folder-close" />folder-close</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-folder-open" />folder-open</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-resize-vertical" />resize-vertical</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-resize-horizontal" />resize-horizontal</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-hdd" />hdd</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-bullhorn" />bullhorn</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span
            class="glyphicon glyphicon-glyph-bell"
          />bell</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-certificate" />certificate</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-thumbs-up" />thumbs-up</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-thumbs-down" />thumbs-down</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-hand-right" />hand-right</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-hand-left" />hand-left</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span
            class="glyphicon glyphicon-hand-top"
          />hand-up</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-hand-down" />hand-down</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span
            class="glyphicon glyphicon-circle-arb-row-right"
          />circle-arb-row-right</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-circle-arb-row-left" />circle-arb-row-left</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-circle-arb-row-top" />circle-arb-row-up</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-circle-arb-row-down" />circle-arb-row-down</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-globe" />globe</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-glyph-wrench" />wrench</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-tasks" />tasks</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span
            class="glyphicon glyphicon-filter"
          />filter</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-glyph-briefcase" />briefcase</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-fullscreen" />fullscreen</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-dashboard" />dashboard</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-glyph-paperclip" />paperclip</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-heart-empty" />heart-empty</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-link" />link</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-phone" />phone</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-glyph-pushpin" />pushpin</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-usd" />usd</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-gbp" />gbp</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-sort" />sort</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-sort-by-alphabet" />sort-by-alphabet</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span
            class="glyphicon glyphicon-sort-by-alphabet-alt"
          />sort-by-alphabet-alt</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-sort-by-order" />sort-by-order</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-sort-by-order-alt" />sort-by-order-alt</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span
            class="glyphicon glyphicon-sort-by-attributes"
          />sort-by-attributes</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span
            class="glyphicon glyphicon-sort-by-attributes-alt"
          />sort-by-attributes-alt</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-unchecked" />unchecked</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span
            class="glyphicon glyphicon-expand"
          />expand</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-collapse" />collapse-down</b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><span class="glyphicon glyphicon-collapse-top" />collapse-up</b-col>
        </b-row>
      </b-tab>
      <b-tab>
        <template slot="title">
         FA 4.7.0 <b-badge variant="danger">new</b-badge>
       </template>
       <h4>Awesome <span class="fw-semi-bold">Font Awesome</span></h4>
       <b-row class="icon-list">
         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/bed"><i
           class="fa fa-bed"
         /> bed</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a
           href="../icon/university"
         ><i class="fa fa-bank" /> bank <span
           class="text-muted"
         >(alias)</span></a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/behance"><i
           class="fa fa-behance"
         /> behance</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a
           href="../icon/behance-square"
         ><i class="fa fa-behance-square" /> behance-square</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/bomb"><i
           class="fa fa-bomb"
         /> bomb</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/building"><i
           class="fa fa-building"
         /> building</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/taxi"><i
           class="fa fa-cab"
         /> cab <span class="text-muted">(alias)</span></a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/car"><i
           class="fa fa-car"
         /> car</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/child"><i
           class="fa fa-child"
         /> child</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a
           href="../icon/circle-o-notch"
         ><i class="fa fa-circle-o-notch" /> circle-o-notch</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/circle-thin"><i
           class="fa fa-circle-thin"
         /> circle-thin</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/codepen"><i
           class="fa fa-codepen"
         /> codepen</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/cube"><i
           class="fa fa-cube"
         /> cube</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/cubes"><i
           class="fa fa-cubes"
         /> cubes</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/database"><i
           class="fa fa-database"
         /> database</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/delicious"><i
           class="fa fa-delicious"
         /> delicious</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a
           href="../icon/deviantart"
         ><i class="fa fa-deviantart" /> deviantart</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/digg"><i
           class="fa fa-digg"
         /> digg</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/drupal"><i
           class="fa fa-drupal"
         /> drupal</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/empire"><i
           class="fa fa-empire"
         /> empire</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a
           href="../icon/envelope-square"
         ><i class="fa fa-envelope-square" />
           envelope-square</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/fax"><i
           class="fa fa-fax"
         /> fax</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a
           href="../icon/file-archive-o"
         ><i class="fa fa-file-archive-o" /> file-archive-o</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a
           href="../icon/file-audio-o"
         ><i class="fa fa-file-audio-o" />
           file-audio-o</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/file-code-o"><i
           class="fa fa-file-code-o"
         /> file-code-o</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a
           href="../icon/file-excel-o"
         ><i class="fa fa-file-excel-o" />
           file-excel-o</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a
           href="../icon/file-image-o"
         ><i class="fa fa-file-image-o" />
           file-image-o</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a
           href="../icon/file-video-o"
         ><i class="fa fa-file-movie-o" /> file-movie-o <span
           class="text-muted"
         >(alias)</span></a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a
           href="../icon/file-pdf-o"
         ><i class="fa fa-file-pdf-o" /> file-pdf-o</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a
           href="../icon/file-image-o"
         ><i class="fa fa-file-photo-o" /> file-photo-o <span
           class="text-muted"
         >(alias)</span></a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a
           href="../icon/file-image-o"
         ><i class="fa fa-file-picture-o" /> file-picture-o
           <span class="text-muted">(alias)</span></a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a
           href="../icon/file-powerpoint-o"
         ><i class="fa fa-file-powerpoint-o" />
           file-powerpoint-o</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a
           href="../icon/file-audio-o"
         ><i class="fa fa-file-sound-o" /> file-sound-o <span
           class="text-muted"
         >(alias)</span></a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a
           href="../icon/file-video-o"
         ><i class="fa fa-file-video-o" />
           file-video-o</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/file-word-o"><i
           class="fa fa-file-word-o"
         /> file-word-o</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a
           href="../icon/file-archive-o"
         ><i class="fa fa-file-zip-o" /> file-zip-o <span
           class="text-muted"
         >(alias)</span></a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/empire"><i
           class="fa fa-ge"
         /> ge <span class="text-muted">(alias)</span></a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/git"><i
           class="fa fa-git"
         /> git</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a
           href="../icon/git-square"
         ><i class="fa fa-git-square" /> git-square</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/google"><i
           class="fa fa-google"
         /> google</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a
           href="../icon/graduation-cap"
         ><i class="fa fa-graduation-cap" /> graduation-cap</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/hacker-news"><i
           class="fa fa-hacker-news"
         /> hacker-news</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/header"><i
           class="fa fa-header"
         /> header</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/history"><i
           class="fa fa-history"
         /> history</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a
           href="../icon/university"
         ><i class="fa fa-institution" /> institution <span
           class="text-muted"
         >(alias)</span></a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/joomla"><i
           class="fa fa-joomla"
         /> joomla</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/jsfiddle"><i
           class="fa fa-jsfiddle"
         /> jsfiddle</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/language"><i
           class="fa fa-language"
         /> language</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/life-ring"><i
           class="fa fa-life-bouy"
         /> life-bouy <span
           class="text-muted"
         >(alias)</span></a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/life-ring"><i
           class="fa fa-life-ring"
         /> life-ring</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/life-ring"><i
           class="fa fa-life-saver"
         /> life-saver <span
           class="text-muted"
         >(alias)</span></a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a
           href="../icon/graduation-cap"
         ><i class="fa fa-mortar-board" /> mortar-board
           <span class="text-muted">(alias)</span></a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/openid"><i
           class="fa fa-openid"
         /> openid</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/paper-plane"><i
           class="fa fa-paper-plane"
         /> paper-plane</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a
           href="../icon/paper-plane-o"
         ><i class="fa fa-paper-plane-o" />
           paper-plane-o</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/paragraph"><i
           class="fa fa-paragraph"
         /> paragraph</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/paw"><i
           class="fa fa-paw"
         /> paw</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a
           href="../icon/pied-piper"
         ><i class="fa fa-pied-piper" /> pied-piper</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a
           href="../icon/pied-piper-alt"
         ><i class="fa fa-pied-piper-alt" /> pied-piper-alt</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a
           href="../icon/pied-piper"
         ><i class="fa fa-pied-piper-square" />
           pied-piper-square <span class="text-muted">(alias)</span></a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/qq"><i
           class="fa fa-qq"
         /> qq</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/rebel"><i
           class="fa fa-ra"
         /> ra <span class="text-muted">(alias)</span></a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/rebel"><i
           class="fa fa-rebel"
         /> rebel</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/recycle"><i
           class="fa fa-recycle"
         /> recycle</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/reddit"><i
           class="fa fa-reddit"
         /> reddit</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a
           href="../icon/reddit-square"
         ><i class="fa fa-reddit-square" />
           reddit-square</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/paper-plane"><i
           class="fa fa-send"
         /> send <span
           class="text-muted"
         >(alias)</span></a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a
           href="../icon/paper-plane-o"
         ><i class="fa fa-send-o" /> send-o <span
           class="text-muted"
         >(alias)</span></a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/share-alt"><i
           class="fa fa-share-alt"
         /> share-alt</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a
           href="../icon/share-alt-square"
         ><i class="fa fa-share-alt-square" />
           share-alt-square</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/slack"><i
           class="fa fa-slack"
         /> slack</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/sliders"><i
           class="fa fa-sliders"
         /> sliders</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a
           href="../icon/soundcloud"
         ><i class="fa fa-soundcloud" /> soundcloud</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a
           href="../icon/space-shuttle"
         ><i class="fa fa-space-shuttle" />
           space-shuttle</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/spoon"><i
           class="fa fa-spoon"
         /> spoon</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/spotify"><i
           class="fa fa-spotify"
         /> spotify</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/steam"><i
           class="fa fa-steam"
         /> steam</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a
           href="../icon/steam-square"
         ><i class="fa fa-steam-square" />
           steam-square</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/stumbleupon"><i
           class="fa fa-stumbleupon"
         /> stumbleupon</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a
           href="../icon/stumbleupon-circle"
         ><i class="fa fa-stumbleupon-circle" />
           stumbleupon-circle</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/life-ring"><i
           class="fa fa-support"
         /> support <span
           class="text-muted"
         >(alias)</span></a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/taxi"><i
           class="fa fa-taxi"
         /> taxi</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a
           href="../icon/tencent-weibo"
         ><i class="fa fa-tencent-weibo" />
           tencent-weibo</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/tree"><i
           class="fa fa-tree"
         /> tree</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a
           href="../icon/university"
         ><i class="fa fa-university" /> university</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/vine"><i
           class="fa fa-vine"
         /> vine</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/weixin"><i
           class="fa fa-wechat"
         /> wechat <span class="text-muted">(alias)</span></a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/weixin"><i
           class="fa fa-weixin"
         /> weixin</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/wordpress"><i
           class="fa fa-wordpress"
         /> wordpress</a></b-col>

         <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/yahoo"><i
           class="fa fa-yahoo"
         /> yahoo</a></b-col>
       </b-row>
      </b-tab>
      <b-tab title="Web Application">
        <b-row class="icon-list">
          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/adjust"><i
            class="fa fa-adjust"
          /> adjust</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/anchor"><i
            class="fa fa-anchor"
          /> anchor</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/archive"><i
            class="fa fa-archive"
          /> archive</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/arrows"><i
            class="fa fa-arrows"
          /> arrows</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/arrows-h"><i
            class="fa fa-arrows-h"
          /> arrows-h</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/arrows-v"><i
            class="fa fa-arrows-v"
          /> arrows-v</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/asterisk"><i
            class="fa fa-asterisk"
          /> asterisk</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/car"><i
            class="fa fa-automobile"
          /> automobile <span
            class="text-muted"
          >(alias)</span></a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/ban"><i
            class="fa fa-ban"
          /> ban</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/university"
          ><i class="fa fa-bank" /> bank <span
            class="text-muted"
          >(alias)</span></a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/bar-chart-o"><i
            class="fa fa-bar-chart-o"
          /> bar-chart-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/barcode"><i
            class="fa fa-barcode"
          /> barcode</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/bars"><i
            class="fa fa-bars"
          /> bars</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/beer"><i
            class="fa fa-beer"
          /> beer</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/bell"><i
            class="fa fa-bell"
          /> bell</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/bell-o"><i
            class="fa fa-bell-o"
          /> bell-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/bolt"><i
            class="fa fa-bolt"
          /> bolt</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/bomb"><i
            class="fa fa-bomb"
          /> bomb</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/book"><i
            class="fa fa-book"
          /> book</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/bookmark"><i
            class="fa fa-bookmark"
          /> bookmark</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/bookmark-o"
          ><i class="fa fa-bookmark-o" /> bookmark-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/briefcase"><i
            class="fa fa-briefcase"
          /> briefcase</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/bug"><i
            class="fa fa-bug"
          /> bug</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/building"><i
            class="fa fa-building"
          /> building</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/building-o"
          ><i class="fa fa-building-o" /> building-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/bullhorn"><i
            class="fa fa-bullhorn"
          /> bullhorn</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/bullseye"><i
            class="fa fa-bullseye"
          /> bullseye</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/taxi"><i
            class="fa fa-cab"
          /> cab <span class="text-muted">(alias)</span></a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/calendar"><i
            class="fa fa-calendar"
          /> calendar</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/calendar-o"
          ><i class="fa fa-calendar-o" /> calendar-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/camera"><i
            class="fa fa-camera"
          /> camera</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/camera-retro"
          ><i class="fa fa-camera-retro" />
            camera-retro</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/car"><i
            class="fa fa-car"
          /> car</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/caret-square-o-down"
          ><i class="fa fa-caret-square-o-down" />
            caret-square-o-down</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/caret-square-o-left"
          ><i class="fa fa-caret-square-o-left" />
            caret-square-o-left</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/caret-square-o-right"
          ><i class="fa fa-caret-square-o-right" />
            caret-square-o-right</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/caret-square-o-up"
          ><i class="fa fa-caret-square-o-up" />
            caret-square-o-up</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/certificate"><i
            class="fa fa-certificate"
          /> certificate</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/check"><i
            class="fa fa-check"
          /> check</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/check-circle"
          ><i class="fa fa-check-circle" />
            check-circle</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/check-circle-o"
          ><i class="fa fa-check-circle-o" /> check-circle-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/check-square"
          ><i class="fa fa-check-square" />
            check-square</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/check-square-o"
          ><i class="fa fa-check-square-o" /> check-square-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/child"><i
            class="fa fa-child"
          /> child</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/circle"><i
            class="fa fa-circle"
          /> circle</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/circle-o"><i
            class="fa fa-circle-o"
          /> circle-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/circle-o-notch"
          ><i class="fa fa-circle-o-notch" /> circle-o-notch</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/circle-thin"><i
            class="fa fa-circle-thin"
          /> circle-thin</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/clock-o"><i
            class="fa fa-clock-o"
          /> clock-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/cloud"><i
            class="fa fa-cloud"
          /> cloud</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/cloud-download"
          ><i class="fa fa-cloud-download" /> cloud-download</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/cloud-upload"
          ><i class="fa fa-cloud-upload" />
            cloud-upload</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/code"><i
            class="fa fa-code"
          /> code</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/code-fork"><i
            class="fa fa-code-fork"
          /> code-fork</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/coffee"><i
            class="fa fa-coffee"
          /> coffee</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/cog"><i
            class="fa fa-cog"
          /> cog</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/cogs"><i
            class="fa fa-cogs"
          /> cogs</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/comment"><i
            class="fa fa-comment"
          /> comment</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/comment-o"><i
            class="fa fa-comment-o"
          /> comment-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/comments"><i
            class="fa fa-comments"
          /> comments</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/comments-o"
          ><i class="fa fa-comments-o" /> comments-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/compass"><i
            class="fa fa-compass"
          /> compass</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/credit-card"><i
            class="fa fa-credit-card"
          /> credit-card</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/crop"><i
            class="fa fa-crop"
          /> crop</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/crosshairs"
          ><i class="fa fa-crosshairs" /> crosshairs</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/cube"><i
            class="fa fa-cube"
          /> cube</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/cubes"><i
            class="fa fa-cubes"
          /> cubes</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/cutlery"><i
            class="fa fa-cutlery"
          /> cutlery</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/tachometer"
          ><i class="fa fa-dashboard" /> dashboard <span
            class="text-muted"
          >(alias)</span></a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/database"><i
            class="fa fa-database"
          /> database</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/desktop"><i
            class="fa fa-desktop"
          /> desktop</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/dot-circle-o"
          ><i class="fa fa-dot-circle-o" />
            dot-circle-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/download"><i
            class="fa fa-download"
          /> download</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/pencil-square-o"
          ><i class="fa fa-edit" /> edit <span
            class="text-muted"
          >(alias)</span></a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/ellipsis-h"
          ><i class="fa fa-ellipsis-h" /> ellipsis-h</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/ellipsis-v"
          ><i class="fa fa-ellipsis-v" /> ellipsis-v</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/envelope"><i
            class="fa fa-envelope"
          /> envelope</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/envelope-o"
          ><i class="fa fa-envelope-o" /> envelope-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/envelope-square"
          ><i class="fa fa-envelope-square" />
            envelope-square</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/eraser"><i
            class="fa fa-eraser"
          /> eraser</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/exchange"><i
            class="fa fa-exchange"
          /> exchange</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/exclamation"><i
            class="fa fa-exclamation"
          /> exclamation</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/exclamation-circle"
          ><i class="fa fa-exclamation-circle" />
            exclamation-circle</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/exclamation-triangle"
          ><i class="fa fa-exclamation-triangle" />
            exclamation-triangle</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/external-link"
          ><i class="fa fa-external-link" />
            external-link</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/external-link-square"
          ><i class="fa fa-external-link-square" />
            external-link-square</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/eye"><i
            class="fa fa-eye"
          /> eye</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/eye-slash"><i
            class="fa fa-eye-slash"
          /> eye-slash</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/fax"><i
            class="fa fa-fax"
          /> fax</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/female"><i
            class="fa fa-female"
          /> female</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/fighter-jet"><i
            class="fa fa-fighter-jet"
          /> fighter-jet</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/file-archive-o"
          ><i class="fa fa-file-archive-o" /> file-archive-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/file-audio-o"
          ><i class="fa fa-file-audio-o" />
            file-audio-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/file-code-o"><i
            class="fa fa-file-code-o"
          /> file-code-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/file-excel-o"
          ><i class="fa fa-file-excel-o" />
            file-excel-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/file-image-o"
          ><i class="fa fa-file-image-o" />
            file-image-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/file-video-o"
          ><i class="fa fa-file-movie-o" /> file-movie-o <span
            class="text-muted"
          >(alias)</span></a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/file-pdf-o"
          ><i class="fa fa-file-pdf-o" /> file-pdf-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/file-image-o"
          ><i class="fa fa-file-photo-o" /> file-photo-o <span
            class="text-muted"
          >(alias)</span></a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/file-image-o"
          ><i class="fa fa-file-picture-o" /> file-picture-o
            <span class="text-muted">(alias)</span></a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/file-powerpoint-o"
          ><i class="fa fa-file-powerpoint-o" />
            file-powerpoint-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/file-audio-o"
          ><i class="fa fa-file-sound-o" /> file-sound-o <span
            class="text-muted"
          >(alias)</span></a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/file-video-o"
          ><i class="fa fa-file-video-o" />
            file-video-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/file-word-o"><i
            class="fa fa-file-word-o"
          /> file-word-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/file-archive-o"
          ><i class="fa fa-file-zip-o" /> file-zip-o <span
            class="text-muted"
          >(alias)</span></a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/film"><i
            class="fa fa-film"
          /> film</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/filter"><i
            class="fa fa-filter"
          /> filter</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/fire"><i
            class="fa fa-fire"
          /> fire</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/fire-extinguisher"
          ><i class="fa fa-fire-extinguisher" />
            fire-extinguisher</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/flag"><i
            class="fa fa-flag"
          /> flag</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/flag-checkered"
          ><i class="fa fa-flag-checkered" /> flag-checkered</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/flag-o"><i
            class="fa fa-flag-o"
          /> flag-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/bolt"><i
            class="fa fa-flash"
          /> flash <span
            class="text-muted"
          >(alias)</span></a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/flask"><i
            class="fa fa-flask"
          /> flask</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/folder"><i
            class="fa fa-folder"
          /> folder</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/folder-o"><i
            class="fa fa-folder-o"
          /> folder-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/folder-open"><i
            class="fa fa-folder-open"
          /> folder-open</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/folder-open-o"
          ><i class="fa fa-folder-open-o" />
            folder-open-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/frown-o"><i
            class="fa fa-frown-o"
          /> frown-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/gamepad"><i
            class="fa fa-gamepad"
          /> gamepad</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/gavel"><i
            class="fa fa-gavel"
          /> gavel</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/cog"><i
            class="fa fa-gear"
          /> gear <span
            class="text-muted"
          >(alias)</span></a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/cogs"><i
            class="fa fa-gears"
          /> gears <span
            class="text-muted"
          >(alias)</span></a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/gift"><i
            class="fa fa-gift"
          /> gift</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/glass"><i
            class="fa fa-glass"
          /> glass</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/globe"><i
            class="fa fa-globe"
          /> globe</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/graduation-cap"
          ><i class="fa fa-graduation-cap" /> graduation-cap</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/users"><i
            class="fa fa-group"
          /> group <span
            class="text-muted"
          >(alias)</span></a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/hdd-o"><i
            class="fa fa-hdd-o"
          /> hdd-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/headphones"
          ><i class="fa fa-headphones" /> headphones</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/heart"><i
            class="fa fa-heart"
          /> heart</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/heart-o"><i
            class="fa fa-heart-o"
          /> heart-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/history"><i
            class="fa fa-history"
          /> history</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/home"><i
            class="fa fa-home"
          /> home</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/picture-o"><i
            class="fa fa-image"
          /> image <span
            class="text-muted"
          >(alias)</span></a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/inbox"><i
            class="fa fa-inbox"
          /> inbox</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/info"><i
            class="fa fa-info"
          /> info</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/info-circle"><i
            class="fa fa-info-circle"
          /> info-circle</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/university"
          ><i class="fa fa-institution" /> institution <span
            class="text-muted"
          >(alias)</span></a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/key"><i
            class="fa fa-key"
          /> key</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/keyboard-o"
          ><i class="fa fa-keyboard-o" /> keyboard-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/language"><i
            class="fa fa-language"
          /> language</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/laptop"><i
            class="fa fa-laptop"
          /> laptop</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/leaf"><i
            class="fa fa-leaf"
          /> leaf</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/gavel"><i
            class="fa fa-legal"
          /> legal <span
            class="text-muted"
          >(alias)</span></a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/lemon-o"><i
            class="fa fa-lemon-o"
          /> lemon-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/level-down"
          ><i class="fa fa-level-down" /> level-down</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/level-up"><i
            class="fa fa-level-up"
          /> level-up</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/life-ring"><i
            class="fa fa-life-bouy"
          /> life-bouy <span
            class="text-muted"
          >(alias)</span></a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/life-ring"><i
            class="fa fa-life-ring"
          /> life-ring</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/life-ring"><i
            class="fa fa-life-saver"
          /> life-saver <span
            class="text-muted"
          >(alias)</span></a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/lightbulb-o"><i
            class="fa fa-lightbulb-o"
          /> lightbulb-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/location-arrow"
          ><i class="fa fa-location-arrow" /> location-arrow</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/lock"><i
            class="fa fa-lock"
          /> lock</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/magic"><i
            class="fa fa-magic"
          /> magic</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/magnet"><i
            class="fa fa-magnet"
          /> magnet</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/share"><i
            class="fa fa-mail-forward"
          /> mail-forward <span
            class="text-muted"
          >(alias)</span></a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/reply"><i
            class="fa fa-mail-reply"
          /> mail-reply <span
            class="text-muted"
          >(alias)</span></a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/reply-all"><i
            class="fa fa-mail-reply-all"
          /> mail-reply-all <span class="text-muted">(alias)</span></a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/male"><i
            class="fa fa-male"
          /> male</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/map-marker"
          ><i class="fa fa-map-marker" /> map-marker</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/meh-o"><i
            class="fa fa-meh-o"
          /> meh-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/microphone"
          ><i class="fa fa-microphone" /> microphone</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/microphone-slash"
          ><i class="fa fa-microphone-slash" />
            microphone-slash</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/minus"><i
            class="fa fa-minus"
          /> minus</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/minus-circle"
          ><i class="fa fa-minus-circle" />
            minus-circle</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/minus-square"
          ><i class="fa fa-minus-square" />
            minus-square</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/minus-square-o"
          ><i class="fa fa-minus-square-o" /> minus-square-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/mobile"><i
            class="fa fa-mobile"
          /> mobile</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/mobile"><i
            class="fa fa-mobile-phone"
          /> mobile-phone <span
            class="text-muted"
          >(alias)</span></a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/money"><i
            class="fa fa-money"
          /> money</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/moon-o"><i
            class="fa fa-moon-o"
          /> moon-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/graduation-cap"
          ><i class="fa fa-mortar-board" /> mortar-board
            <span class="text-muted">(alias)</span></a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/music"><i
            class="fa fa-music"
          /> music</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/bars"><i
            class="fa fa-navicon"
          /> navicon <span
            class="text-muted"
          >(alias)</span></a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/paper-plane"><i
            class="fa fa-paper-plane"
          /> paper-plane</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/paper-plane-o"
          ><i class="fa fa-paper-plane-o" />
            paper-plane-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/paw"><i
            class="fa fa-paw"
          /> paw</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/pencil"><i
            class="fa fa-pencil"
          /> pencil</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/pencil-square"
          ><i class="fa fa-pencil-square" />
            pencil-square</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/pencil-square-o"
          ><i class="fa fa-pencil-square-o" />
            pencil-square-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/phone"><i
            class="fa fa-phone"
          /> phone</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/phone-square"
          ><i class="fa fa-phone-square" />
            phone-square</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/picture-o"><i
            class="fa fa-photo"
          /> photo <span
            class="text-muted"
          >(alias)</span></a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/picture-o"><i
            class="fa fa-picture-o"
          /> picture-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/plane"><i
            class="fa fa-plane"
          /> plane</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/plus"><i
            class="fa fa-plus"
          /> plus</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/plus-circle"><i
            class="fa fa-plus-circle"
          /> plus-circle</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/plus-square"><i
            class="fa fa-plus-square"
          /> plus-square</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/plus-square-o"
          ><i class="fa fa-plus-square-o" />
            plus-square-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/power-off"><i
            class="fa fa-power-off"
          /> power-off</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/print"><i
            class="fa fa-print"
          /> print</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/puzzle-piece"
          ><i class="fa fa-puzzle-piece" />
            puzzle-piece</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/qrcode"><i
            class="fa fa-qrcode"
          /> qrcode</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/question"><i
            class="fa fa-question"
          /> question</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/question-circle"
          ><i class="fa fa-question-circle" />
            question-circle</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/quote-left"
          ><i class="fa fa-quote-left" /> quote-left</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/quote-right"><i
            class="fa fa-quote-right"
          /> quote-right</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/random"><i
            class="fa fa-random"
          /> random</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/recycle"><i
            class="fa fa-recycle"
          /> recycle</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/refresh"><i
            class="fa fa-refresh"
          /> refresh</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/bars"><i
            class="fa fa-reorder"
          /> reorder <span
            class="text-muted"
          >(alias)</span></a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/reply"><i
            class="fa fa-reply"
          /> reply</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/reply-all"><i
            class="fa fa-reply-all"
          /> reply-all</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/retweet"><i
            class="fa fa-retweet"
          /> retweet</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/road"><i
            class="fa fa-road"
          /> road</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/rocket"><i
            class="fa fa-rocket"
          /> rocket</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/rss"><i
            class="fa fa-rss"
          /> rss</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/rss-square"
          ><i class="fa fa-rss-square" /> rss-square</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/search"><i
            class="fa fa-search"
          /> search</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/search-minus"
          ><i class="fa fa-search-minus" />
            search-minus</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/search-plus"><i
            class="fa fa-search-plus"
          /> search-plus</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/paper-plane"><i
            class="fa fa-send"
          /> send <span
            class="text-muted"
          >(alias)</span></a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/paper-plane-o"
          ><i class="fa fa-send-o" /> send-o <span
            class="text-muted"
          >(alias)</span></a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/share"><i
            class="fa fa-share"
          /> share</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/share-alt"><i
            class="fa fa-share-alt"
          /> share-alt</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/share-alt-square"
          ><i class="fa fa-share-alt-square" />
            share-alt-square</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/share-square"
          ><i class="fa fa-share-square" />
            share-square</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/share-square-o"
          ><i class="fa fa-share-square-o" /> share-square-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/shield"><i
            class="fa fa-shield"
          /> shield</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/shopping-cart"
          ><i class="fa fa-shopping-cart" />
            shopping-cart</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/sign-in"><i
            class="fa fa-sign-in"
          /> sign-in</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/sign-out"><i
            class="fa fa-sign-out"
          /> sign-out</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/signal"><i
            class="fa fa-signal"
          /> signal</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/sitemap"><i
            class="fa fa-sitemap"
          /> sitemap</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/sliders"><i
            class="fa fa-sliders"
          /> sliders</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/smile-o"><i
            class="fa fa-smile-o"
          /> smile-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/sort"><i
            class="fa fa-sort"
          /> sort</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/sort-alpha-asc"
          ><i class="fa fa-sort-alpha-asc" /> sort-alpha-asc</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/sort-alpha-desc"
          ><i class="fa fa-sort-alpha-desc" />
            sort-alpha-desc</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/sort-amount-asc"
          ><i class="fa fa-sort-amount-asc" />
            sort-amount-asc</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/sort-amount-desc"
          ><i class="fa fa-sort-amount-desc" />
            sort-amount-desc</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/sort-asc"><i
            class="fa fa-sort-asc"
          /> sort-asc</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/sort-desc"><i
            class="fa fa-sort-desc"
          /> sort-desc</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/sort-desc"><i
            class="fa fa-sort-down"
          /> sort-down <span
            class="text-muted"
          >(alias)</span></a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/sort-numeric-asc"
          ><i class="fa fa-sort-numeric-asc" />
            sort-numeric-asc</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/sort-numeric-desc"
          ><i class="fa fa-sort-numeric-desc" />
            sort-numeric-desc</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/sort-asc"><i
            class="fa fa-sort-up"
          /> sort-up <span
            class="text-muted"
          >(alias)</span></a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/space-shuttle"
          ><i class="fa fa-space-shuttle" />
            space-shuttle</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/spinner"><i
            class="fa fa-spinner"
          /> spinner</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/spoon"><i
            class="fa fa-spoon"
          /> spoon</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/square"><i
            class="fa fa-square"
          /> square</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/square-o"><i
            class="fa fa-square-o"
          /> square-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/star"><i
            class="fa fa-star"
          /> star</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/star-half"><i
            class="fa fa-star-half"
          /> star-half</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/star-half-o"><i
            class="fa fa-star-half-empty"
          /> star-half-empty <span class="text-muted">(alias)</span></a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/star-half-o"><i
            class="fa fa-star-half-full"
          /> star-half-full <span class="text-muted">(alias)</span></a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/star-half-o"><i
            class="fa fa-star-half-o"
          /> star-half-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/star-o"><i
            class="fa fa-star-o"
          /> star-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/suitcase"><i
            class="fa fa-suitcase"
          /> suitcase</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/sun-o"><i
            class="fa fa-sun-o"
          /> sun-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/life-ring"><i
            class="fa fa-support"
          /> support <span
            class="text-muted"
          >(alias)</span></a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/tablet"><i
            class="fa fa-tablet"
          /> tablet</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/tachometer"
          ><i class="fa fa-tachometer" /> tachometer</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/tag"><i
            class="fa fa-tag"
          /> tag</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/tags"><i
            class="fa fa-tags"
          /> tags</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/tasks"><i
            class="fa fa-tasks"
          /> tasks</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/taxi"><i
            class="fa fa-taxi"
          /> taxi</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/terminal"><i
            class="fa fa-terminal"
          /> terminal</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/thumb-tack"
          ><i class="fa fa-thumb-tack" /> thumb-tack</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/thumbs-down"><i
            class="fa fa-thumbs-down"
          /> thumbs-down</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/thumbs-o-down"
          ><i class="fa fa-thumbs-o-down" />
            thumbs-o-down</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/thumbs-o-up"><i
            class="fa fa-thumbs-o-up"
          /> thumbs-o-up</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/thumbs-up"><i
            class="fa fa-thumbs-up"
          /> thumbs-up</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/ticket"><i
            class="fa fa-ticket"
          /> ticket</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/times"><i
            class="fa fa-times"
          /> times</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/times-circle"
          ><i class="fa fa-times-circle" />
            times-circle</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/times-circle-o"
          ><i class="fa fa-times-circle-o" /> times-circle-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/tint"><i
            class="fa fa-tint"
          /> tint</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/caret-square-o-down"
          ><i class="fa fa-toggle-down" /> toggle-down
            <span class="text-muted">(alias)</span></a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/caret-square-o-left"
          ><i class="fa fa-toggle-left" /> toggle-left
            <span class="text-muted">(alias)</span></a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/caret-square-o-right"
          ><i class="fa fa-toggle-right" />
            toggle-right <span class="text-muted">(alias)</span></a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/caret-square-o-up"
          ><i class="fa fa-toggle-up" /> toggle-up <span
            class="text-muted"
          >(alias)</span></a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/trash-o"><i
            class="fa fa-trash-o"
          /> trash-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/tree"><i
            class="fa fa-tree"
          /> tree</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/trophy"><i
            class="fa fa-trophy"
          /> trophy</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/truck"><i
            class="fa fa-truck"
          /> truck</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/umbrella"><i
            class="fa fa-umbrella"
          /> umbrella</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/university"
          ><i class="fa fa-university" /> university</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/unlock"><i
            class="fa fa-unlock"
          /> unlock</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/unlock-alt"
          ><i class="fa fa-unlock-alt" /> unlock-alt</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/sort"><i
            class="fa fa-unsorted"
          /> unsorted <span class="text-muted">(alias)</span></a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/upload"><i
            class="fa fa-upload"
          /> upload</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/user"><i
            class="fa fa-user"
          /> user</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/users"><i
            class="fa fa-users"
          /> users</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/video-camera"
          ><i class="fa fa-video-camera" />
            video-camera</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/volume-down"><i
            class="fa fa-volume-down"
          /> volume-down</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/volume-off"
          ><i class="fa fa-volume-off" /> volume-off</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/volume-up"><i
            class="fa fa-volume-up"
          /> volume-up</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/exclamation-triangle"
          ><i class="fa fa-warning" /> warning <span
            class="text-muted"
          >(alias)</span></a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/wheelchair"
          ><i class="fa fa-wheelchair" /> wheelchair</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/wrench"><i
            class="fa fa-wrench"
          /> wrench</a></b-col>
        </b-row>
      </b-tab>
      <b-tab title="Spinner">
        <b-row class="icon-list">
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><a
            href="../icon/circle-o-notch"
          ><i class="fa fa-circle-o-notch" /> circle-o-notch</a></b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/cog"><i
            class="fa fa-cog"
          /> cog</a></b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/cog"><i
            class="fa fa-gear"
          /> gear <span
            class="text-muted"
          >(alias)</span></a></b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/refresh"><i
            class="fa fa-refresh"
          /> refresh</a></b-col>
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/spinner"><i
            class="fa fa-spinner"
          /> spinner</a></b-col>
        </b-row>
      </b-tab>
      <b-tab title="Text Editor">
        <b-row class="icon-list">
          <b-col md="4" lg="3" xs="12" class="icon-list-item"><a
            href="../icon/align-center"
          ><i class="fa fa-align-center" />
            align-center</a></b-col>

          <b-col md="4" lg="3" xs="12" class="icon-list-item"><a
            href="../icon/align-justify"
          ><i class="fa fa-align-justify" />
            align-justify</a></b-col>

          <b-col md="4" lg="3" xs="12" class="icon-list-item"><a
            href="../icon/align-left"
          ><i class="fa fa-align-left" /> align-left</a></b-col>

          <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/align-right"><i
            class="fa fa-align-right"
          /> align-right</a></b-col>

          <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/bold"><i
            class="fa fa-bold"
          /> bold</a></b-col>

          <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/link"><i
            class="fa fa-chain"
          /> chain <span
            class="text-muted"
          >(alias)</span></a></b-col>

          <b-col md="4" lg="3" xs="12" class="icon-list-item"><a
            href="../icon/chain-broken"
          ><i class="fa fa-chain-broken" />
            chain-broken</a></b-col>

          <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/clipboard"><i
            class="fa fa-clipboard"
          /> clipboard</a></b-col>

          <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/columns"><i
            class="fa fa-columns"
          /> columns</a></b-col>

          <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/files-o"><i
            class="fa fa-copy"
          /> copy <span
            class="text-muted"
          >(alias)</span></a></b-col>

          <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/scissors"><i
            class="fa fa-cut"
          /> cut <span class="text-muted">(alias)</span></a></b-col>

          <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/outdent"><i
            class="fa fa-dedent"
          /> dedent <span class="text-muted">(alias)</span></a></b-col>

          <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/eraser"><i
            class="fa fa-eraser"
          /> eraser</a></b-col>

          <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/file"><i
            class="fa fa-file"
          /> file</a></b-col>

          <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/file-o"><i
            class="fa fa-file-o"
          /> file-o</a></b-col>

          <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/file-text"><i
            class="fa fa-file-text"
          /> file-text</a></b-col>

          <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/file-text-o"><i
            class="fa fa-file-text-o"
          /> file-text-o</a></b-col>

          <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/files-o"><i
            class="fa fa-files-o"
          /> files-o</a></b-col>

          <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/floppy-o"><i
            class="fa fa-floppy-o"
          /> floppy-o</a></b-col>

          <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/font"><i
            class="fa fa-font"
          /> font</a></b-col>

          <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/header"><i
            class="fa fa-header"
          /> header</a></b-col>

          <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/indent"><i
            class="fa fa-indent"
          /> indent</a></b-col>

          <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/italic"><i
            class="fa fa-italic"
          /> italic</a></b-col>

          <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/link"><i
            class="fa fa-link"
          /> link</a></b-col>

          <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/list"><i
            class="fa fa-list"
          /> list</a></b-col>

          <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/list-alt"><i
            class="fa fa-list-alt"
          /> list-alt</a></b-col>

          <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/list-ol"><i
            class="fa fa-list-ol"
          /> list-ol</a></b-col>

          <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/list-ul"><i
            class="fa fa-list-ul"
          /> list-ul</a></b-col>

          <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/outdent"><i
            class="fa fa-outdent"
          /> outdent</a></b-col>

          <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/paperclip"><i
            class="fa fa-paperclip"
          /> paperclip</a></b-col>

          <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/paragraph"><i
            class="fa fa-paragraph"
          /> paragraph</a></b-col>

          <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/clipboard"><i
            class="fa fa-paste"
          /> paste <span
            class="text-muted"
          >(alias)</span></a></b-col>

          <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/repeat"><i
            class="fa fa-repeat"
          /> repeat</a></b-col>

          <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/undo"><i
            class="fa fa-rotate-left"
          /> rotate-left <span
            class="text-muted"
          >(alias)</span></a></b-col>

          <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/repeat"><i
            class="fa fa-rotate-right"
          /> rotate-right <span
            class="text-muted"
          >(alias)</span></a></b-col>

          <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/floppy-o"><i
            class="fa fa-save"
          /> save <span
            class="text-muted"
          >(alias)</span></a></b-col>

          <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/scissors"><i
            class="fa fa-scissors"
          /> scissors</a></b-col>

          <b-col md="4" lg="3" xs="12" class="icon-list-item"><a
            href="../icon/strikethrough"
          ><i class="fa fa-strikethrough" />
            strikethrough</a></b-col>

          <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/subscript"><i
            class="fa fa-subscript"
          /> subscript</a></b-col>

          <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/superscript"><i
            class="fa fa-superscript"
          /> superscript</a></b-col>

          <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/table"><i
            class="fa fa-table"
          /> table</a></b-col>

          <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/text-height"><i
            class="fa fa-text-height"
          /> text-height</a></b-col>

          <b-col md="4" lg="3" xs="12" class="icon-list-item"><a
            href="../icon/text-width"
          ><i class="fa fa-text-width" /> text-width</a></b-col>

          <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/th"><i
            class="fa fa-th"
          /> th</a></b-col>

          <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/th-large"><i
            class="fa fa-th-large"
          /> th-large</a></b-col>

          <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/th-list"><i
            class="fa fa-th-list"
          /> th-list</a></b-col>

          <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/underline"><i
            class="fa fa-underline"
          /> underline</a></b-col>

          <b-col md="4" lg="3" xs="12" class="icon-list-item"><a href="../icon/undo"><i
            class="fa fa-undo"
          /> undo</a></b-col>

          <b-col md="4" lg="3" xs="12" class="icon-list-item"><a
            href="../icon/chain-broken"
          ><i class="fa fa-unlink" /> unlink <span
            class="text-muted"
          >(alias)</span></a></b-col>
        </b-row>
      </b-tab>
      <b-tab title="Brand">
        <b-row class="icon-list">
          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/adn"><i
            class="fa fa-adn"
          /> adn</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/android"><i
            class="fa fa-android"
          /> android</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/apple"><i
            class="fa fa-apple"
          /> apple</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/behance"><i
            class="fa fa-behance"
          /> behance</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/behance-square"
          ><i class="fa fa-behance-square" /> behance-square</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/bitbucket"><i
            class="fa fa-bitbucket"
          /> bitbucket</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/bitbucket-square"
          ><i class="fa fa-bitbucket-square" />
            bitbucket-square</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/btc"><i
            class="fa fa-bitcoin"
          /> bitcoin <span
            class="text-muted"
          >(alias)</span></a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/btc"><i
            class="fa fa-btc"
          /> btc</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/codepen"><i
            class="fa fa-codepen"
          /> codepen</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/css3"><i
            class="fa fa-css3"
          /> css3</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/delicious"><i
            class="fa fa-delicious"
          /> delicious</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/deviantart"
          ><i class="fa fa-deviantart" /> deviantart</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/digg"><i
            class="fa fa-digg"
          /> digg</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/dribbble"><i
            class="fa fa-dribbble"
          /> dribbble</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/dropbox"><i
            class="fa fa-dropbox"
          /> dropbox</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/drupal"><i
            class="fa fa-drupal"
          /> drupal</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/empire"><i
            class="fa fa-empire"
          /> empire</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/facebook"><i
            class="fa fa-facebook"
          /> facebook</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/facebook-square"
          ><i class="fa fa-facebook-square" />
            facebook-square</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/flickr"><i
            class="fa fa-flickr"
          /> flickr</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/foursquare"
          ><i class="fa fa-foursquare" /> foursquare</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/empire"><i
            class="fa fa-ge"
          /> ge <span class="text-muted">(alias)</span></a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/git"><i
            class="fa fa-git"
          /> git</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/git-square"
          ><i class="fa fa-git-square" /> git-square</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/github"><i
            class="fa fa-github"
          /> github</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/github-alt"
          ><i class="fa fa-github-alt" /> github-alt</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/github-square"
          ><i class="fa fa-github-square" />
            github-square</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/gittip"><i
            class="fa fa-gittip"
          /> gittip</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/google"><i
            class="fa fa-google"
          /> google</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/google-plus"><i
            class="fa fa-google-plus"
          /> google-plus</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/google-plus-square"
          ><i class="fa fa-google-plus-square" />
            google-plus-square</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/hacker-news"><i
            class="fa fa-hacker-news"
          /> hacker-news</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/html5"><i
            class="fa fa-html5"
          /> html5</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/instagram"><i
            class="fa fa-instagram"
          /> instagram</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/joomla"><i
            class="fa fa-joomla"
          /> joomla</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/jsfiddle"><i
            class="fa fa-jsfiddle"
          /> jsfiddle</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/linkedin"><i
            class="fa fa-linkedin"
          /> linkedin</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/linkedin-square"
          ><i class="fa fa-linkedin-square" />
            linkedin-square</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/linux"><i
            class="fa fa-linux"
          /> linux</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/maxcdn"><i
            class="fa fa-maxcdn"
          /> maxcdn</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/openid"><i
            class="fa fa-openid"
          /> openid</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/pagelines"><i
            class="fa fa-pagelines"
          /> pagelines</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/pied-piper"
          ><i class="fa fa-pied-piper" /> pied-piper</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/pied-piper-alt"
          ><i class="fa fa-pied-piper-alt" /> pied-piper-alt</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/pied-piper"
          ><i class="fa fa-pied-piper-square" />
            pied-piper-square <span class="text-muted">(alias)</span></a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/pinterest"><i
            class="fa fa-pinterest"
          /> pinterest</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/pinterest-square"
          ><i class="fa fa-pinterest-square" />
            pinterest-square</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/qq"><i
            class="fa fa-qq"
          /> qq</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/rebel"><i
            class="fa fa-ra"
          /> ra <span class="text-muted">(alias)</span></a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/rebel"><i
            class="fa fa-rebel"
          /> rebel</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/reddit"><i
            class="fa fa-reddit"
          /> reddit</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/reddit-square"
          ><i class="fa fa-reddit-square" />
            reddit-square</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/renren"><i
            class="fa fa-renren"
          /> renren</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/share-alt"><i
            class="fa fa-share-alt"
          /> share-alt</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/share-alt-square"
          ><i class="fa fa-share-alt-square" />
            share-alt-square</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/skype"><i
            class="fa fa-skype"
          /> skype</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/slack"><i
            class="fa fa-slack"
          /> slack</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/soundcloud"
          ><i class="fa fa-soundcloud" /> soundcloud</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/spotify"><i
            class="fa fa-spotify"
          /> spotify</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/stack-exchange"
          ><i class="fa fa-stack-exchange" /> stack-exchange</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/stack-overflow"
          ><i class="fa fa-stack-overflow" /> stack-overflow</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/steam"><i
            class="fa fa-steam"
          /> steam</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/steam-square"
          ><i class="fa fa-steam-square" />
            steam-square</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/stumbleupon"><i
            class="fa fa-stumbleupon"
          /> stumbleupon</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/stumbleupon-circle"
          ><i class="fa fa-stumbleupon-circle" />
            stumbleupon-circle</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/tencent-weibo"
          ><i class="fa fa-tencent-weibo" />
            tencent-weibo</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/trello"><i
            class="fa fa-trello"
          /> trello</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/tumblr"><i
            class="fa fa-tumblr"
          /> tumblr</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/tumblr-square"
          ><i class="fa fa-tumblr-square" />
            tumblr-square</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/twitter"><i
            class="fa fa-twitter"
          /> twitter</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/twitter-square"
          ><i class="fa fa-twitter-square" /> twitter-square</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/vimeo-square"
          ><i class="fa fa-vimeo-square" />
            vimeo-square</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/vine"><i
            class="fa fa-vine"
          /> vine</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/vk"><i
            class="fa fa-vk"
          /> vk</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/weixin"><i
            class="fa fa-wechat"
          /> wechat <span class="text-muted">(alias)</span></a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/weibo"><i
            class="fa fa-weibo"
          /> weibo</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/weixin"><i
            class="fa fa-weixin"
          /> weixin</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/windows"><i
            class="fa fa-windows"
          /> windows</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/wordpress"><i
            class="fa fa-wordpress"
          /> wordpress</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/xing"><i
            class="fa fa-xing"
          /> xing</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/xing-square"><i
            class="fa fa-xing-square"
          /> xing-square</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/yahoo"><i
            class="fa fa-yahoo"
          /> yahoo</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/youtube"><i
            class="fa fa-youtube"
          /> youtube</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/youtube-play"
          ><i class="fa fa-youtube-play" />
            youtube-play</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/youtube-square"
          ><i class="fa fa-youtube-square" /> youtube-square</a></b-col>
        </b-row>
      </b-tab>
      <b-tab title="Other">
        <h4>File Type <span class="fw-semi-bold">Icons</span></h4>
        <b-row class="icon-list">
          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/file"><i
            class="fa fa-file"
          /> file</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/file-archive-o"
          ><i class="fa fa-file-archive-o" /> file-archive-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/file-audio-o"
          ><i class="fa fa-file-audio-o" />
            file-audio-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/file-code-o"><i
            class="fa fa-file-code-o"
          /> file-code-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/file-excel-o"
          ><i class="fa fa-file-excel-o" />
            file-excel-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/file-image-o"
          ><i class="fa fa-file-image-o" />
            file-image-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/file-video-o"
          ><i class="fa fa-file-movie-o" /> file-movie-o <span
            class="text-muted"
          >(alias)</span></a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/file-o"><i
            class="fa fa-file-o"
          /> file-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/file-pdf-o"
          ><i class="fa fa-file-pdf-o" /> file-pdf-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/file-image-o"
          ><i class="fa fa-file-photo-o" /> file-photo-o <span
            class="text-muted"
          >(alias)</span></a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/file-image-o"
          ><i class="fa fa-file-picture-o" /> file-picture-o
            <span class="text-muted">(alias)</span></a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/file-powerpoint-o"
          ><i class="fa fa-file-powerpoint-o" />
            file-powerpoint-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/file-audio-o"
          ><i class="fa fa-file-sound-o" /> file-sound-o <span
            class="text-muted"
          >(alias)</span></a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/file-text"><i
            class="fa fa-file-text"
          /> file-text</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/file-text-o"><i
            class="fa fa-file-text-o"
          /> file-text-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/file-video-o"
          ><i class="fa fa-file-video-o" />
            file-video-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/file-word-o"><i
            class="fa fa-file-word-o"
          /> file-word-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/file-archive-o"
          ><i class="fa fa-file-zip-o" /> file-zip-o <span
            class="text-muted"
          >(alias)</span></a></b-col>
        </b-row>

        <h4 class="mt-3">Form Control <span class="fw-semi-bold">Icons</span></h4>
        <b-row class="icon-list">
          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/check-square"
          ><i class="fa fa-check-square" />
            check-square</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/check-square-o"
          ><i class="fa fa-check-square-o" /> check-square-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/circle"><i
            class="fa fa-circle"
          /> circle</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/circle-o"><i
            class="fa fa-circle-o"
          /> circle-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/dot-circle-o"
          ><i class="fa fa-dot-circle-o" />
            dot-circle-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/minus-square"
          ><i class="fa fa-minus-square" />
            minus-square</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/minus-square-o"
          ><i class="fa fa-minus-square-o" /> minus-square-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/plus-square"><i
            class="fa fa-plus-square"
          /> plus-square</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/plus-square-o"
          ><i class="fa fa-plus-square-o" />
            plus-square-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/square"><i
            class="fa fa-square"
          /> square</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/square-o"><i
            class="fa fa-square-o"
          /> square-o</a></b-col>
        </b-row>

        <h4 class="mt-3">Currency <span class="fw-semi-bold">Icons</span></h4>
        <b-row class="icon-list">
          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/btc"><i
            class="fa fa-bitcoin"
          /> bitcoin <span
            class="text-muted"
          >(alias)</span></a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/btc"><i
            class="fa fa-btc"
          /> btc</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/jpy"><i
            class="fa fa-cny"
          /> cny <span class="text-muted">(alias)</span></a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/usd"><i
            class="fa fa-dollar"
          /> dollar <span class="text-muted">(alias)</span></a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/eur"><i
            class="fa fa-eur"
          /> eur</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/eur"><i
            class="fa fa-euro"
          /> euro <span
            class="text-muted"
          >(alias)</span></a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/gbp"><i
            class="fa fa-gbp"
          /> gbp</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/inr"><i
            class="fa fa-inr"
          /> inr</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/jpy"><i
            class="fa fa-jpy"
          /> jpy</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/krw"><i
            class="fa fa-krw"
          /> krw</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/money"><i
            class="fa fa-money"
          /> money</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/jpy"><i
            class="fa fa-rmb"
          /> rmb <span class="text-muted">(alias)</span></a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/rub"><i
            class="fa fa-rouble"
          /> rouble <span class="text-muted">(alias)</span></a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/rub"><i
            class="fa fa-rub"
          /> rub</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/rub"><i
            class="fa fa-ruble"
          /> ruble <span
            class="text-muted"
          >(alias)</span></a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/inr"><i
            class="fa fa-rupee"
          /> rupee <span
            class="text-muted"
          >(alias)</span></a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/try"><i
            class="fa fa-try"
          /> try</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/try"><i
            class="fa fa-turkish-lira"
          /> turkish-lira <span
            class="text-muted"
          >(alias)</span></a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/usd"><i
            class="fa fa-usd"
          /> usd</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/krw"><i
            class="fa fa-won"
          /> won <span class="text-muted">(alias)</span></a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/jpy"><i
            class="fa fa-yen"
          /> yen <span class="text-muted">(alias)</span></a></b-col>
        </b-row>

        <h4 class="mt-3">Video Player <span class="fw-semi-bold">Icons</span></h4>
        <b-row class="icon-list">

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/arrows-alt"
          ><i class="fa fa-arrows-alt" /> arrows-alt</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/backward"><i
            class="fa fa-backward"
          /> backward</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/compress"><i
            class="fa fa-compress"
          /> compress</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/eject"><i
            class="fa fa-eject"
          /> eject</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/expand"><i
            class="fa fa-expand"
          /> expand</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/fast-backward"
          ><i class="fa fa-fast-backward" />
            fast-backward</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/fast-forward"
          ><i class="fa fa-fast-forward" />
            fast-forward</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/forward"><i
            class="fa fa-forward"
          /> forward</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/pause"><i
            class="fa fa-pause"
          /> pause</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/play"><i
            class="fa fa-play"
          /> play</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/play-circle"><i
            class="fa fa-play-circle"
          /> play-circle</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/play-circle-o"
          ><i class="fa fa-play-circle-o" />
            play-circle-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/step-backward"
          ><i class="fa fa-step-backward" />
            step-backward</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/step-forward"
          ><i class="fa fa-step-forward" />
            step-forward</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/stop"><i
            class="fa fa-stop"
          /> stop</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/youtube-play"
          ><i class="fa fa-youtube-play" />
            youtube-play</a></b-col>
        </b-row>

        <h4 class="mt-3">Medical <span class="fw-semi-bold">Icons</span></h4>
        <b-row class="icon-list">
          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/ambulance"><i
            class="fa fa-ambulance"
          /> ambulance</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/h-square"><i
            class="fa fa-h-square"
          /> h-square</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/hospital-o"
          ><i class="fa fa-hospital-o" /> hospital-o</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/medkit"><i
            class="fa fa-medkit"
          /> medkit</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/plus-square"><i
            class="fa fa-plus-square"
          /> plus-square</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/stethoscope"><i
            class="fa fa-stethoscope"
          /> stethoscope</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a href="../icon/user-md"><i
            class="fa fa-user-md"
          /> user-md</a></b-col>

          <b-col class="icon-list-item" lg="3" md="4" xs="12"><a
            href="../icon/wheelchair"
          ><i class="fa fa-wheelchair" /> wheelchair</a></b-col>
        </b-row>
      </b-tab>
    </b-tabs>
  </section>
</template>

<script>
export default {
  name: 'Icons',
};
</script>

<script src="./Icons.scss" lang="scss" scoped />
