# vue-cli

## Project setup
```
yarn install
```

### Compiles and hot-reloads for development
```
yarn run start
```

### If you use app with backend support, please use
```
yarn run start:backend
```

### Compiles and minifies for production
```
yarn run build
```

### Run your tests
```
yarn run test
```

### Lints and fixes files
```
yarn run lint
```
