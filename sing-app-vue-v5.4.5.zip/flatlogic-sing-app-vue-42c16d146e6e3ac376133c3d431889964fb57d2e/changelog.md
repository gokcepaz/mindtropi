# Changelog
## [5.4.5]

### Fixed

- Much work has been done to improve and correct a lot of small bugs.

## [5.4.4]

### Fixed

- Update dependency

## [5.4.3]

### Fixed

- Update dependency
- Fix animation class
- Fix link in them helper

## [5.4.2]

### Fixed

- Fix invalid token validation

## [5.4.1]

### New Features

- added new seed version
- added some chat functionality
- updated documentation

### Fixed

- fixed bugs

## [5.4.0]

### New Features

- added brand new chat component

### Fixed

- removed old chat sidebar
- fixed bugs

## [5.3.1]

### Updated

- updated and fixed tour component

### Fixed

- fixed bugs

## [5.3.0]

### Updated

- updated design
- updated customization colors
