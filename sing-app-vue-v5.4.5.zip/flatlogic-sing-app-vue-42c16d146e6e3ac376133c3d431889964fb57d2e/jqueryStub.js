// this is an workaround of jquery requirement for the vue-bootstrap-slide library
module.exports = null;